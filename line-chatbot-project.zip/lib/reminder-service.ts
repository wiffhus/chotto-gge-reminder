import { supabase } from './supabase'

export interface PendingReminder {
  id: string
  user_id: string
  target_hour: number
  target_minute: number
  content: string | null
  is_wake_up: boolean
  created_at: string
  notification_interval?: number // 新フィールド
}

export interface Reminder {
  id: string
  user_id: string
  target_datetime: string
  content: string | null
  is_wake_up: boolean
  is_active: boolean
  created_at: string
  notification_interval: number // 新フィールド
}

export interface ReminderNotification {
  id: string
  reminder_id: string
  sent_at: string
}

// 時刻パターンを解析
export function parseTimeFromMessage(message: string): {
  hour: number | null
  minute: number | null
  content: string | null
  isWakeUp: boolean
} {
  // 様々な時刻パターンに対応
  const timePatterns = [
    // 「15:45に買い物して」「8:33に起こして」
    /(\d{1,2})[:.時](\d{1,2})\s*分?\s*に\s*(.*?)(?:って|と|を)?\s*(伝えて|教えて|起こして|リマインド|して)/i,
    // 「8時半に起こして」「7時15分に買い物」
    /(\d{1,2})\s*時\s*(?:(\d{1,2})\s*分|半)?\s*に\s*(.*?)(?:って|と|を)?\s*(伝えて|教えて|起こして|リマインド|して)/i,
    // 「午後3時45分に」「夜8時に」
    /(午前|午後|朝|夜|昼)?\s*(\d{1,2})\s*時\s*(\d{1,2})?\s*分?\s*に\s*(.*?)(?:って|と|を)?\s*(伝えて|教えて|起こして|リマインド|して)/i,
    // 「8.33に起こして」（ドット区切り）
    /(\d{1,2})\.(\d{1,2})\s*に\s*(.*?)(?:って|と|を)?\s*(伝えて|教えて|起こして|リマインド|して)/i
  ]

  for (const pattern of timePatterns) {
    const match = message.match(pattern)
    if (match) {
      let hour: number
      let minute: number
      let content: string
      let period = ''

      if (match.length === 6 && match[1] && (match[1].includes('午') || match[1].includes('朝') || match[1].includes('夜') || match[1].includes('昼'))) {
        // 午前/午後パターン
        period = match[1]
        hour = parseInt(match[2])
        minute = match[3] ? parseInt(match[3]) : 0
        content = match[4] || ''
      } else {
        // 通常パターン
        hour = parseInt(match[1])
        minute = match[2] ? (match[2] === '半' ? 30 : parseInt(match[2])) : 0
        content = match[3] || ''
      }

      // 午後の場合は12時間加算（ただし12時は除く）
      if (period === '午後' && hour !== 12) {
        hour += 12
      } else if (period === '午前' && hour === 12) {
        hour = 0
      } else if (period === '夜' && hour <= 11) {
        hour += 12
      }

      const isWakeUp = /(起こして|目覚まし)/i.test(message)

      return {
        hour,
        minute,
        content: isWakeUp ? null : content.trim(),
        isWakeUp
      }
    }
  }

  return {
    hour: null,
    minute: null,
    content: null,
    isWakeUp: false
  }
}

// 現在時刻を考慮した時刻解釈
export function interpretTime(hour: number, minute: number): { finalHour: number, needsConfirmation: boolean } {
  const now = new Date()
  const currentHour = now.getHours()
  
  let finalHour = hour
  let needsConfirmation = false

  // 12時間以下の場合、AM/PM判定
  if (hour <= 12) {
    if (currentHour >= 0 && currentHour <= 6 && hour >= 7) {
      // 深夜～早朝で、7時以降を指定 → その日の朝
      finalHour = hour
    } else if (currentHour >= 7 && currentHour <= 12 && hour >= 1 && hour <= 6) {
      // 朝～昼で、1-6時を指定 → 翌日の早朝
      finalHour = hour
    } else if (currentHour >= 13 && currentHour <= 23 && hour >= 1 && hour <= 12) {
      // 午後～夜で、1-12時を指定
      if (hour >= 7 && hour <= 11) {
        // 7-11時の場合は夜の可能性を確認
        finalHour = hour + 12
        needsConfirmation = true
      } else {
        // 翌日
        finalHour = hour
      }
    }
  }

  return { finalHour, needsConfirmation }
}

// 目標日時を計算
export function calculateTargetDate(hour: number, minute: number): Date {
  const now = new Date()
  const target = new Date()
  target.setHours(hour, minute, 0, 0)

  // 指定時刻が現在時刻より過去の場合、翌日に設定
  if (target <= now) {
    target.setDate(target.getDate() + 1)
  }

  return target
}

// 保留中のリマインダーを保存
export async function savePendingReminder(
  userId: string,
  hour: number,
  minute: number,
  content: string | null,
  isWakeUp: boolean,
  notificationInterval: number = 5 // 新フィールド
): Promise<void> {
  try {
    const { error } = await supabase
      .from('pending_reminders')
      .upsert({
        user_id: userId,
        target_hour: hour,
        target_minute: minute,
        content: content,
        is_wake_up: isWakeUp,
        notification_interval: notificationInterval, // 新フィールド
        created_at: new Date().toISOString()
      })

    if (error) {
      console.error('Error saving pending reminder:', error)
      throw error
    }
  } catch (error) {
    console.error('Error in savePendingReminder:', error)
    throw error
  }
}

// 保留中のリマインダーを取得
export async function getPendingReminder(userId: string): Promise<PendingReminder | null> {
  try {
    const { data, error } = await supabase
      .from('pending_reminders')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()

    if (error && error.code !== 'PGRST116') {
      console.error('Error getting pending reminder:', error)
      return null
    }

    return data || null
  } catch (error) {
    console.error('Error in getPendingReminder:', error)
    return null
  }
}

// リマインダーを確定
export async function confirmReminder(userId: string): Promise<boolean> {
  try {
    const pending = await getPendingReminder(userId)
    if (!pending) {
      return false
    }

    // 目標日時を計算
    const targetDate = calculateTargetDate(pending.target_hour, pending.target_minute)

    // リマインダーを正式に設定
    const { error: insertError } = await supabase
      .from('reminders')
      .insert({
        user_id: userId,
        target_datetime: targetDate.toISOString(),
        content: pending.content,
        is_wake_up: pending.is_wake_up,
        notification_interval: pending.notification_interval || 5, // 新フィールド
        is_active: true
      })

    if (insertError) {
      console.error('Error inserting reminder:', insertError)
      return false
    }

    // 保留中のリマインダーを削除
    const { error: deleteError } = await supabase
      .from('pending_reminders')
      .delete()
      .eq('user_id', userId)

    if (deleteError) {
      console.error('Error deleting pending reminder:', deleteError)
    }

    return true
  } catch (error) {
    console.error('Error in confirmReminder:', error)
    return false
  }
}

// リマインダーをキャンセル
export async function cancelPendingReminder(userId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('pending_reminders')
      .delete()
      .eq('user_id', userId)

    if (error) {
      console.error('Error canceling pending reminder:', error)
      return false
    }

    return true
  } catch (error) {
    console.error('Error in cancelPendingReminder:', error)
    return false
  }
}

// アクティブな目覚ましを停止
export async function stopWakeUpAlarm(userId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('reminders')
      .update({ is_active: false })
      .eq('user_id', userId)
      .eq('is_wake_up', true)
      .eq('is_active', true)
      .select()

    if (error) {
      console.error('Error stopping wake up alarm:', error)
      return false
    }

    return data && data.length > 0
  } catch (error) {
    console.error('Error in stopWakeUpAlarm:', error)
    return false
  }
}

const NEWS_API_KEY = process.env.NEWS_API_KEY!
const SERPER_API_KEY = process.env.SERPER_API_KEY!

export interface NewsArticle {
  title: string
  description: string
  url: string
  source: string
  publishedAt: string
}

export async function getLocalNews(locationName: string, limit: number = 5): Promise<NewsArticle[]> {
  try {
    // まずNews APIで地域ニュースを取得
    const newsApiResults = await getNewsFromNewsAPI(locationName, limit)
    
    // Serper APIでも検索して補完
    const serperResults = await getNewsFromSerper(locationName, limit)
    
    // 結果をマージして重複を除去
    const allNews = [...newsApiResults, ...serperResults]
    const uniqueNews = allNews.filter((article, index, self) => 
      index === self.findIndex(a => a.title === article.title)
    )
    
    return uniqueNews.slice(0, limit)
  } catch (error) {
    console.error('Local news error:', error)
    return []
  }
}

async function getNewsFromNewsAPI(locationName: string, limit: number): Promise<NewsArticle[]> {
  try {
    const query = `${locationName} OR "${locationName}"`
    const response = await fetch(
      `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&language=ja&sortBy=publishedAt&pageSize=${limit}&apiKey=${NEWS_API_KEY}`
    )

    if (!response.ok) {
      console.error('News API error:', response.status)
      return []
    }

    const data = await response.json()
    
    return (data.articles || []).map((article: any) => ({
      title: article.title,
      description: article.description || '',
      url: article.url,
      source: article.source.name,
      publishedAt: article.publishedAt
    }))
  } catch (error) {
    console.error('News API fetch error:', error)
    return []
  }
}

async function getNewsFromSerper(locationName: string, limit: number): Promise<NewsArticle[]> {
  try {
    const response = await fetch('https://google.serper.dev/news', {
      method: 'POST',
      headers: {
        'X-API-KEY': SERPER_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        q: `${locationName} ニュース`,
        num: limit,
        hl: 'ja',
        gl: 'jp',
      }),
    })

    if (!response.ok) {
      return []
    }

    const data = await response.json()
    
    return (data.news || []).map((article: any) => ({
      title: article.title,
      description: article.snippet || '',
      url: article.link,
      source: article.source || 'Google News',
      publishedAt: article.date || new Date().toISOString()
    }))
  } catch (error) {
    console.error('Serper news error:', error)
    return []
  }
}

export function formatNewsResponse(articles: NewsArticle[], locationName: string): string {
  if (articles.length === 0) {
    return `${locationName}の最新ニュースが見つからへんかった。もう少し広い地域で調べてみるわ。`
  }

  let response = `【${locationName}の最新ニュース】\n\n`
  
  articles.slice(0, 3).forEach((article, index) => {
    response += `${index + 1}. ${article.title}\n`
    if (article.description) {
      response += `${article.description.substring(0, 100)}...\n`
    }
    response += `出典: ${article.source}\n\n`
  })

  return response
}

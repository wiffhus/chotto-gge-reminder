import { generateObject } from 'ai'
import { openai } from '@ai-sdk/openai'
import { z } from 'zod'

const ProfileExtractionSchema = z.object({
  nickname: z.string().nullable().describe('ユーザーが申告した名前やニックネーム'),
  hobbies: z.array(z.string()).describe('新しく判明した趣味'),
  preferences: z.record(z.any()).describe('食べ物の好み、場所、その他の設定'),
  hasImportantInfo: z.boolean().describe('重要な個人情報が含まれているかどうか')
})

export async function extractProfileInfo(message: string): Promise<{
  nickname: string | null
  hobbies: string[]
  preferences: Record<string, any>
  hasImportantInfo: boolean
}> {
  try {
    const { object } = await generateObject({
      model: openai('gpt-4o'),
      schema: ProfileExtractionSchema,
      prompt: `
以下のメッセージから、ユーザーの重要な個人情報を抽出してください。

メッセージ: "${message}"

抽出対象：
1. nickname: ユーザーが自分の名前やニックネームを言った場合（「私は田中です」「○○と呼んで」など）
2. hobbies: 趣味について言及した場合（「映画が好き」「ゲームをやる」など）
3. preferences: 食べ物の好み、住んでいる場所、その他の設定
4. hasImportantInfo: 上記のような重要情報が含まれているかどうか

雑談や一時的な話題（天気、今日の出来事など）は抽出しないでください。
`,
    })

    return object
  } catch (error) {
    console.error('Error extracting profile info:', error)
    return {
      nickname: null,
      hobbies: [],
      preferences: {},
      hasImportantInfo: false
    }
  }
}

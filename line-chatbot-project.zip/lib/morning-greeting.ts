import { getUserProfile } from './user-profile'
import { getUserLastLocation } from './location-service'
import { getWeatherByCoordinates, getLocationName } from './weather-service'
import { getLocalNews } from './news-service'
import { performEnhancedSearch } from './enhanced-search'

export interface MorningInfo {
  isFirstOfDay: boolean
  isGreeting: boolean
  weatherInfo: string
  newsInfo: string
  locationName: string
}

// 一日の最初の入力かどうかを判定（6時間以上経過）
export function isFirstInteractionOfDay(lastConversationTime: string | null): boolean {
  if (!lastConversationTime) return true
  
  const lastTime = new Date(lastConversationTime)
  const now = new Date()
  const hoursDiff = (now.getTime() - lastTime.getTime()) / (1000 * 60 * 60)
  
  return hoursDiff >= 6
}

// 挨拶・呼びかけかどうかを判定
export function isGreetingMessage(message: string): boolean {
  const greetingPatterns = [
    /おはよう/i,
    /こんにちは/i,
    /こんばんは/i,
    /おっちゃん(?!.*[？?])/i, // 「おっちゃん」だけで質問でない場合
    /元気/i,
    /調子/i,
    /久しぶり/i,
    /お疲れ/i,
    /ただいま/i,
    /起きた/i,
    /おきた/i
  ]
  
  // メッセージが短く（30文字以下）、挨拶パターンにマッチする場合
  return message.length <= 30 && greetingPatterns.some(pattern => pattern.test(message))
}

// 朝の情報（天気・ニュース）を取得
export async function getMorningInfo(userId: string): Promise<MorningInfo> {
  try {
    const userProfile = await getUserProfile(userId)
    const lastLocation = await getUserLastLocation(userProfile)
    
    let weatherInfo = ''
    let newsInfo = ''
    let locationName = '現在地'
    
    if (lastLocation) {
      // 位置情報がある場合
      locationName = await getLocationName(lastLocation.latitude, lastLocation.longitude)
      
      // 天気情報を取得
      const weather = await getWeatherByCoordinates(lastLocation.latitude, lastLocation.longitude)
      if (weather) {
        const current = weather.current
        weatherInfo = `今日の${locationName}は${current.description}で${current.temperature}度の予定やで`
        
        // 雨の場合は傘の提案
        if (current.description.includes('雨') || current.description.includes('雷')) {
          weatherInfo += '。傘持って行った方がええな'
        }
        
        // 暑い・寒い場合のアドバイス
        if (current.temperature >= 30) {
          weatherInfo += '。暑いから水分補給忘れんようにな'
        } else if (current.temperature <= 5) {
          weatherInfo += '。寒いから暖かくして出かけや'
        }
      }
      
      // 地域ニュースを取得
      const localNews = await getLocalNews(locationName, 2)
      if (localNews.length > 0) {
        const topNews = localNews[0]
        newsInfo = `そうそう、${locationName}で${topNews.title.substring(0, 50)}...って話題になってるで`
      }
    } else {
      // 位置情報がない場合は一般的なニュースを取得
      const generalNews = await performEnhancedSearch('日本 最新ニュース 今日', 'news')
      if (generalNews.summary) {
        newsInfo = `最近のニュースやと、${generalNews.summary.substring(0, 100)}...って感じやな`
      }
    }
    
    return {
      isFirstOfDay: true,
      isGreeting: true,
      weatherInfo,
      newsInfo,
      locationName
    }
  } catch (error) {
    console.error('Error getting morning info:', error)
    return {
      isFirstOfDay: true,
      isGreeting: true,
      weatherInfo: '',
      newsInfo: '',
      locationName: '現在地'
    }
  }
}

// 朝の挨拶レスポンスを生成
export function generateMorningResponse(
  originalMessage: string, 
  morningInfo: MorningInfo,
  userNickname?: string
): string {
  const timeOfDay = new Date().getHours()
  let greeting = ''
  
  // 時間帯に応じた挨拶
  if (timeOfDay < 10) {
    greeting = 'おはよう'
  } else if (timeOfDay < 18) {
    greeting = 'こんにちは'
  } else {
    greeting = 'こんばんは'
  }
  
  // ユーザー名があれば使用
  const nameCall = userNickname ? `、${userNickname}` : ''
  
  let response = `${greeting}${nameCall}！元気しとったか？`
  
  // 天気情報を自然に組み込み
  if (morningInfo.weatherInfo) {
    response += `\n\n${morningInfo.weatherInfo}。`
  }
  
  // ニュース情報を自然に組み込み
  if (morningInfo.newsInfo) {
    response += `\n\n${morningInfo.newsInfo}。`
  }
  
  // 締めの言葉
  if (timeOfDay < 12) {
    response += '\n\n今日も一日頑張ろうや！'
  } else if (timeOfDay < 18) {
    response += '\n\n今日もお疲れさん！'
  } else {
    response += '\n\n今日もお疲れさまやったな！'
  }
  
  return response
}

// 時間帯を判定
export function getTimeOfDay(): 'morning' | 'afternoon' | 'evening' {
  const hour = new Date().getHours()
  
  if (hour >= 5 && hour < 12) {
    return 'morning'
  } else if (hour >= 12 && hour < 18) {
    return 'afternoon'
  } else {
    return 'evening'
  }
}

const OPENWEATHER_API_KEY = process.env.OPENWEATHER_API_KEY!

export interface WeatherData {
  location: string
  current: {
    temperature: number
    description: string
    humidity: number
    windSpeed: number
    feelsLike: number
  }
  forecast: Array<{
    time: string
    temperature: number
    description: string
    precipitation: number
  }>
}

export async function getWeatherByCoordinates(lat: number, lon: number): Promise<WeatherData | null> {
  try {
    // 現在の天気を取得
    const currentResponse = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_API_KEY}&units=metric&lang=ja`
    )

    if (!currentResponse.ok) {
      throw new Error(`OpenWeather API error: ${currentResponse.status}`)
    }

    const currentData = await currentResponse.json()

    // 5日間の予報を取得
    const forecastResponse = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_API_KEY}&units=metric&lang=ja`
    )

    const forecastData = forecastResponse.ok ? await forecastResponse.json() : null

    // 今日の時間別予報（次の24時間）
    const hourlyForecast = forecastData?.list?.slice(0, 8).map((item: any) => ({
      time: new Date(item.dt * 1000).toLocaleTimeString('ja-JP', { 
        hour: '2-digit', 
        minute: '2-digit' 
      }),
      temperature: Math.round(item.main.temp),
      description: item.weather[0].description,
      precipitation: item.pop * 100 // 降水確率
    })) || []

    return {
      location: currentData.name || '現在地',
      current: {
        temperature: Math.round(currentData.main.temp),
        description: currentData.weather[0].description,
        humidity: currentData.main.humidity,
        windSpeed: Math.round(currentData.wind?.speed * 3.6 || 0), // m/s to km/h
        feelsLike: Math.round(currentData.main.feels_like)
      },
      forecast: hourlyForecast
    }
  } catch (error) {
    console.error('Weather API error:', error)
    return null
  }
}

export async function getLocationName(lat: number, lon: number): Promise<string> {
  try {
    const response = await fetch(
      `https://api.openweathermap.org/geo/1.0/reverse?lat=${lat}&lon=${lon}&limit=1&appid=${OPENWEATHER_API_KEY}`
    )

    if (!response.ok) {
      return '現在地'
    }

    const data = await response.json()
    if (data && data.length > 0) {
      const location = data[0]
      return location.local_names?.ja || location.name || '現在地'
    }

    return '現在地'
  } catch (error) {
    console.error('Reverse geocoding error:', error)
    return '現在地'
  }
}

export function formatWeatherResponse(weather: WeatherData): string {
  const current = weather.current
  const location = weather.location

  let response = `【${location}の天気】\n`
  response += `現在：${current.description} ${current.temperature}°C\n`
  response += `体感温度：${current.feelsLike}°C\n`
  response += `湿度：${current.humidity}% / 風速：${current.windSpeed}km/h\n\n`

  if (weather.forecast.length > 0) {
    response += `【今後の予報】\n`
    weather.forecast.slice(0, 4).forEach(forecast => {
      response += `${forecast.time}: ${forecast.description} ${forecast.temperature}°C`
      if (forecast.precipitation > 0) {
        response += ` (降水${Math.round(forecast.precipitation)}%)`
      }
      response += `\n`
    })
  }

  return response
}

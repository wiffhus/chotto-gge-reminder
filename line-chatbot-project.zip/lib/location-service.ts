import { upsertUserProfile } from './user-profile'

export interface LocationData {
  latitude: number
  longitude: number
  address?: string
  timestamp: string
}

export async function saveUserLocation(userId: string, lat: number, lon: number, address?: string): Promise<void> {
  try {
    const locationData: LocationData = {
      latitude: lat,
      longitude: lon,
      address,
      timestamp: new Date().toISOString()
    }

    await upsertUserProfile(userId, {
      preferences: {
        lastLocation: locationData
      }
    })

    console.log(`Saved location for user ${userId}:`, locationData)
  } catch (error) {
    console.error('Error saving user location:', error)
  }
}

export async function getUserLastLocation(userProfile: any): Promise<LocationData | null> {
  try {
    if (userProfile?.preferences?.lastLocation) {
      return userProfile.preferences.lastLocation
    }
    return null
  } catch (error) {
    console.error('Error getting user location:', error)
    return null
  }
}

export function isLocationRecent(location: LocationData, hoursThreshold: number = 24): boolean {
  const locationTime = new Date(location.timestamp)
  const now = new Date()
  const hoursDiff = (now.getTime() - locationTime.getTime()) / (1000 * 60 * 60)
  
  return hoursDiff <= hoursThreshold
}

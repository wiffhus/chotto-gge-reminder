import { supabase } from './supabase'

export interface UserProfile {
  user_id: string
  hobbies: string[]
  preferences: Record<string, any>
  nickname: string | null
  subscription_status: 'free' | 'premium'
  created_at: string
  updated_at: string
}

// ユーザープロフィールを取得
export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  try {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('user_id', userId)
      .single()

    if (error && error.code !== 'PGRST116') { // PGRST116 = not found
      console.error('Error fetching user profile:', error)
      return null
    }

    return data || null
  } catch (error) {
    console.error('Error in getUserProfile:', error)
    return null
  }
}

// ユーザープロフィールを作成または更新
export async function upsertUserProfile(userId: string, updates: Partial<UserProfile>): Promise<void> {
  try {
    const { error } = await supabase
      .from('user_profiles')
      .upsert({
        user_id: userId,
        ...updates,
        updated_at: new Date().toISOString()
      })

    if (error) {
      console.error('Error upserting user profile:', error)
    }
  } catch (error) {
    console.error('Error in upsertUserProfile:', error)
  }
}

// ニックネームを更新
export async function updateNickname(userId: string, nickname: string): Promise<void> {
  await upsertUserProfile(userId, { nickname })
}

// 趣味を追加
export async function addHobby(userId: string, hobby: string): Promise<void> {
  try {
    const profile = await getUserProfile(userId)
    const currentHobbies = profile?.hobbies || []
    
    if (!currentHobbies.includes(hobby)) {
      const newHobbies = [...currentHobbies, hobby]
      await upsertUserProfile(userId, { hobbies: newHobbies })
    }
  } catch (error) {
    console.error('Error adding hobby:', error)
  }
}

// 好みを更新
export async function updatePreference(userId: string, key: string, value: any): Promise<void> {
  try {
    const profile = await getUserProfile(userId)
    const currentPreferences = profile?.preferences || {}
    
    const newPreferences = {
      ...currentPreferences,
      [key]: value
    }
    
    await upsertUserProfile(userId, { preferences: newPreferences })
  } catch (error) {
    console.error('Error updating preference:', error)
  }
}

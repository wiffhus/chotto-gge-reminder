import { generateText } from 'ai'
import { openai } from '@ai-sdk/openai'

export async function analyzeImageForSearch(imageData: string): Promise<{
  analysis: string
  searchableItems: string[]
  locations: string[]
  products: string[]
  stores: string[]
}> {
  try {
    const { text } = await generateText({
      model: openai('gpt-4o'),
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: `この画像を詳しく分析して、以下の情報を抽出してください：

1. 画像の全体的な説明
2. 検索可能なアイテム（商品名、ブランド名など）
3. 場所や地名（看板、標識、建物名など）
4. 店舗名やレストラン名
5. その他検索に役立つ情報

JSON形式で以下のように回答してください：
{
  "analysis": "画像の詳細な説明",
  "searchableItems": ["商品名1", "商品名2"],
  "locations": ["場所1", "場所2"],
  "products": ["商品1", "商品2"],
  "stores": ["店舗1", "店舗2"]
}`
            },
            {
              type: 'image',
              image: imageData
            }
          ]
        }
      ],
      maxTokens: 1000,
    })

    try {
      const parsed = JSON.parse(text)
      return {
        analysis: parsed.analysis || '',
        searchableItems: parsed.searchableItems || [],
        locations: parsed.locations || [],
        products: parsed.products || [],
        stores: parsed.stores || []
      }
    } catch {
      return {
        analysis: text,
        searchableItems: [],
        locations: [],
        products: [],
        stores: []
      }
    }
  } catch (error) {
    console.error('Error analyzing image:', error)
    return {
      analysis: '',
      searchableItems: [],
      locations: [],
      products: [],
      stores: []
    }
  }
}

const SERPER_API_KEY = process.env.SERPER_API_KEY!

export interface SearchResult {
  title: string
  snippet: string
  link: string
  source: string
}

export interface EnhancedSearchResults {
  organic: SearchResult[]
  news?: SearchResult[]
  shopping?: SearchResult[]
  summary: string
}

// 複数の検索を並行実行
export async function performEnhancedSearch(
  query: string, 
  searchType: 'news' | 'general' | 'location' | 'product' | 'realtime'
): Promise<EnhancedSearchResults> {
  try {
    const searches = []
    
    // メイン検索
    searches.push(searchGoogle(query, 'search'))
    
    // 検索タイプに応じて追加検索
    if (searchType === 'news' || searchType === 'realtime') {
      searches.push(searchGoogle(query, 'news'))
    }
    
    if (searchType === 'product') {
      searches.push(searchGoogle(`${query} 評判 口コミ`, 'search'))
      searches.push(searchGoogle(query, 'shopping'))
    }
    
    if (searchType === 'location') {
      searches.push(searchGoogle(`${query} 営業時間 アクセス`, 'search'))
    }

    const results = await Promise.all(searches)
    
    const organicResults = results[0]?.organic || []
    const newsResults = results[1]?.organic || []
    const shoppingResults = results[2]?.shopping || []
    
    // 検索結果をまとめて要約
    const summary = await summarizeSearchResults(organicResults, newsResults, query)
    
    return {
      organic: organicResults,
      news: newsResults,
      shopping: shoppingResults,
      summary
    }
  } catch (error) {
    console.error('Enhanced search error:', error)
    return {
      organic: [],
      summary: '検索中にエラーが発生しました。'
    }
  }
}

async function searchGoogle(query: string, type: 'search' | 'news' | 'shopping' = 'search') {
  try {
    const endpoint = type === 'news' ? 'news' : type === 'shopping' ? 'shopping' : 'search'
    
    const response = await fetch(`https://google.serper.dev/${endpoint}`, {
      method: 'POST',
      headers: {
        'X-API-KEY': SERPER_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        q: query,
        num: type === 'shopping' ? 5 : 6,
        hl: 'ja',
        gl: 'jp',
      }),
    })

    if (!response.ok) {
      throw new Error(`Serper API error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error(`Search error for ${type}:`, error)
    return null
  }
}

async function summarizeSearchResults(organic: any[], news: any[], query: string): Promise<string> {
  try {
    const allResults = [...organic.slice(0, 4), ...news.slice(0, 2)]
    
    if (allResults.length === 0) {
      return '関連する情報が見つかりませんでした。'
    }
    
    const resultsText = allResults.map(result => 
      `タイトル: ${result.title}\n内容: ${result.snippet}`
    ).join('\n\n')
    
    const { generateText } = await import('ai')
    const { openai } = await import('@ai-sdk/openai')
    
    const { text } = await generateText({
      model: openai('gpt-4o'),
      prompt: `
以下の検索結果を、関西弁を話すおっちゃんの視点で、自然で親しみやすい形にまとめてください。

検索クエリ: "${query}"

検索結果:
${resultsText}

要件:
- 重要な情報を関西弁で自然に説明
- 友達に話すような親しみやすい口調
- 情報源は明記しない（自然な会話として）
- 長すぎず、要点を押さえて
- 「検索結果によると」などの表現は使わない
`,
      maxTokens: 400,
    })
    
    return text
  } catch (error) {
    console.error('Error summarizing search results:', error)
    return '検索結果をまとめる際にエラーが発生しました。'
  }
}

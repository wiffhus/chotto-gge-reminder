import { generateObject } from 'ai'
import { openai } from '@ai-sdk/openai'
import { z } from 'zod'

const SearchAnalysisSchema = z.object({
  needsSearch: z.boolean().describe('インターネット検索が必要かどうか'),
  searchQuery: z.string().describe('検索に使用するクエリ'),
  searchReason: z.string().describe('検索が必要な理由'),
  searchType: z.enum(['news', 'general', 'location', 'product', 'realtime']).describe('検索の種類')
})

export async function analyzeSearchNeed(message: string, imageAnalysis?: string): Promise<{
  needsSearch: boolean
  searchQuery: string
  searchReason: string
  searchType: 'news' | 'general' | 'location' | 'product' | 'realtime'
}> {
  try {
    const { object } = await generateObject({
      model: openai('gpt-4o'),
      schema: SearchAnalysisSchema,
      prompt: `
以下のメッセージ（および画像解析結果）について、インターネット検索が必要かどうかを判断してください。

メッセージ: "${message}"
${imageAnalysis ? `画像解析結果: "${imageAnalysis}"` : ''}

検索が必要な場合の例：
1. 最新のニュース、天気、株価、スポーツ結果など
2. 現在の情報（今日、現在、最新など）
3. 特定の店舗、商品、場所の詳細情報
4. AIの学習データに含まれていない可能性が高い専門的・最新の情報
5. 画像に写っている店舗名、商品名、場所などの詳細情報
6. 評判、口コミ、レビューなどの情報

検索が不要な場合の例：
1. 一般的な雑談、挨拶
2. 個人的な相談や感情的な内容
3. 基本的な知識や常識的な質問
4. 計算や論理的思考で解決できる問題

適切な検索クエリを日本語で作成してください。
`,
    })

    return object
  } catch (error) {
    console.error('Error analyzing search need:', error)
    return {
      needsSearch: false,
      searchQuery: '',
      searchReason: '',
      searchType: 'general'
    }
  }
}

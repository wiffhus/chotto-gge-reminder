-- 【Phase 1】リマインダー機能用テーブル作成

-- 1. 保留中のリマインダーテーブル（確認待ち状態）
CREATE TABLE IF NOT EXISTS pending_reminders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  target_hour INTEGER NOT NULL,
  target_minute INTEGER NOT NULL,
  content TEXT,
  is_wake_up BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. 確定済みリマインダーテーブル
CREATE TABLE IF NOT EXISTS reminders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  target_datetime TIMESTAMP WITH TIME ZONE NOT NULL,
  content TEXT,
  is_wake_up BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. リマインダー通知履歴テーブル（目覚ましの回数管理用）
CREATE TABLE IF NOT EXISTS reminder_notifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  reminder_id UUID REFERENCES reminders(id) ON DELETE CASCADE,
  sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- インデックス作成（パフォーマンス向上）
CREATE INDEX IF NOT EXISTS idx_pending_reminders_user_id ON pending_reminders(user_id);
CREATE INDEX IF NOT EXISTS idx_reminders_user_id ON reminders(user_id);
CREATE INDEX IF NOT EXISTS idx_reminders_active_datetime ON reminders(is_active, target_datetime);
CREATE INDEX IF NOT EXISTS idx_reminder_notifications_reminder_id ON reminder_notifications(reminder_id);

-- RLS (Row Level Security) 設定
ALTER TABLE pending_reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE reminder_notifications ENABLE ROW LEVEL SECURITY;

-- サービスロール用のポリシー（APIからのアクセス用）
CREATE POLICY IF NOT EXISTS "Service role can manage pending_reminders" ON pending_reminders
  FOR ALL USING (true);

CREATE POLICY IF NOT EXISTS "Service role can manage reminders" ON reminders
  FOR ALL USING (true);

CREATE POLICY IF NOT EXISTS "Service role can manage reminder_notifications" ON reminder_notifications
  FOR ALL USING (true);

-- 既存テーブルに間隔設定カラムを追加

-- 1. pending_reminders テーブルに間隔カラム追加
ALTER TABLE pending_reminders
ADD COLUMN IF NOT EXISTS notification_interval INTEGER DEFAULT 5;

-- 2. reminders テーブルに間隔カラム追加
ALTER TABLE reminders
ADD COLUMN IF NOT EXISTS notification_interval INTEGER DEFAULT 5;

-- 会話履歴を保存するテーブルを作成
CREATE TABLE IF NOT EXISTS conversations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id TEXT NOT NULL,
  message TEXT NOT NULL,
  sender TEXT NOT NULL CHECK (sender IN ('user', 'bot')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- インデックスを作成してクエリを高速化
CREATE INDEX IF NOT EXISTS idx_conversations_user_id_created_at 
ON conversations (user_id, created_at DESC);

-- Row Level Security (RLS) を有効化
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

-- 全てのユーザーが自分の会話履歴にアクセスできるポリシー
CREATE POLICY IF NOT EXISTS "Users can access their own conversations" 
ON conversations FOR ALL 
USING (true);

'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MessageCircle, Bot, Smartphone, Zap, Search, Globe } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <MessageCircle className="h-12 w-12 text-green-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900">LINE AI Chatbot</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            OpenAI APIとGoogle検索を組み合わせた高機能AIアシスタント
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bot className="h-6 w-6 mr-2 text-blue-600" />
                AI Assistant
              </CardTitle>
              <CardDescription>
                OpenAI GPT-4oによる高度な対話
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  カスタムプロンプト使用
                </li>
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  自然な日本語対話
                </li>
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  質問応答・相談対応
                </li>
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  文章生成・要約
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Search className="h-6 w-6 mr-2 text-purple-600" />
                リアルタイム検索
              </CardTitle>
              <CardDescription>
                複数APIによる最新情報取得
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  Google検索（Serper API）
                </li>
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  位置情報対応天気予報
                </li>
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  地域別ニュース取得
                </li>
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  専門情報の調査
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Smartphone className="h-6 w-6 mr-2 text-green-600" />
                LINE連携
              </CardTitle>
              <CardDescription>
                LINE Messaging API統合
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  リアルタイム応答
                </li>
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  セキュア通信
                </li>
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  エラーハンドリング
                </li>
                <li className="flex items-center">
                  <Badge variant="secondary" className="mr-2">✓</Badge>
                  長文メッセージ対応
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Globe className="h-6 w-6 mr-2 text-indigo-600" />
              使用例
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold mb-2 text-blue-800">天気・位置情報</h3>
                <p className="text-sm text-blue-600">
                  位置情報共有→詳細な天気予報、「地元のニュース教えて」
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <h3 className="font-semibold mb-2 text-green-800">最新情報の質問</h3>
                <p className="text-sm text-green-600">
                  「今日のニュースは？」「○○の株価は？」「トレンド情報」
                </p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <h3 className="font-semibold mb-2 text-purple-800">トレンド情報</h3>
                <p className="text-sm text-purple-600">
                  「今話題の○○って何？」「流行りの○○を教えて」
                </p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <h3 className="font-semibold mb-2 text-orange-800">一般的な質問</h3>
                <p className="text-sm text-orange-600">
                  「○○の作り方は？」「○○に行く方法は？」
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Zap className="h-6 w-6 mr-2 text-yellow-600" />
              セットアップ完了！
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <h3 className="font-semibold mb-2 text-green-800">✅ 環境変数設定済み</h3>
                <ul className="text-sm text-green-600 space-y-1">
                  <li>• OPENAI_API_KEY</li>
                  <li>• OPENAI_PROMPT_ID</li>
                  <li>• LINE_CHANNEL_SECRET</li>
                  <li>• LINE_CHANNEL_ACCESS_TOKEN</li>
                  <li>• SERPER_API_KEY</li>
                  <li>• OPENWEATHER_API_KEY</li>
                  <li>• NEWS_API_KEY</li>
                </ul>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold mb-2">次のステップ</h3>
                <ol className="text-sm text-gray-600 space-y-1 list-decimal list-inside">
                  <li>LINE DevelopersでWebhook URLを設定</li>
                  <li>アプリケーションをデプロイ</li>
                  <li>LINEボットをテスト</li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>技術スタック</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Badge>Next.js 15</Badge>
              <Badge>AI SDK</Badge>
              <Badge>OpenAI GPT-4o</Badge>
              <Badge>OpenWeather API</Badge>
              <Badge>News API</Badge>
              <Badge>Serper API</Badge>
              <Badge>LINE Messaging API</Badge>
              <Badge>TypeScript</Badge>
              <Badge>Tailwind CSS</Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

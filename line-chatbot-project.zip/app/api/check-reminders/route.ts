import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

const LINE_CHANNEL_ACCESS_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN!
const REMINDER_API_SECRET = process.env.REMINDER_API_SECRET!

// GitHub Actionsからの定期実行用エンドポイント
export async function POST(request: NextRequest) {
  try {
    // セキュリティ: GitHub Actionsからの呼び出しのみ許可
    const authHeader = request.headers.get('authorization')
    if (!authHeader || authHeader !== `Bearer ${REMINDER_API_SECRET}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const now = new Date()
    console.log('Checking reminders at:', now.toISOString())

    // 実行すべきリマインダーを取得（現在時刻から5分前まで）
    const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000)

    const { data: reminders, error } = await supabase
      .from('reminders')
      .select('*')
      .eq('is_active', true)
      .lte('target_datetime', now.toISOString())
      .gte('target_datetime', fiveMinutesAgo.toISOString())

    if (error) {
      console.error('Database error:', error)
      return NextResponse.json({ error: 'Database error' }, { status: 500 })
    }

    console.log(`Found ${reminders.length} reminders to process`)

    for (const reminder of reminders) {
      await processReminder(reminder)
    }

    return NextResponse.json({
      status: 'success',
      processed: reminders.length,
      timestamp: now.toISOString()
    })
  } catch (error) {
    console.error('Error in check-reminders:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

async function processReminder(reminder: any) {
  try {
    console.log('Processing reminder:', reminder.id)
    
    if (reminder.is_wake_up) {
      // 目覚ましの場合
      await handleWakeUpReminder(reminder)
    } else {
      // 通常のリマインダーの場合
      await handleRegularReminder(reminder)
    }
  } catch (error) {
    console.error('Error processing reminder:', reminder.id, error)
  }
}

async function handleWakeUpReminder(reminder: any) {
  // 最後の通知時刻を取得
  const { data: notifications } = await supabase
    .from('reminder_notifications')
    .select('*')
    .eq('reminder_id', reminder.id)
    .order('sent_at', { ascending: false })
    .limit(1);

  const now = new Date();
  const notificationInterval = reminder.notification_interval || 5; // デフォルト5分

  // 最初の通知かチェック
  if (!notifications || notifications.length === 0) {
    // 設定時刻に達しているかチェック
    const targetTime = new Date(reminder.target_datetime);
    if (now >= targetTime) {
      // 最初の通知を送信
      const message = 'おはよ〜！起きる時間やで〜！';
      await sendLineMessage(reminder.user_id, message);
      
      // 通知記録を追加
      await supabase
        .from('reminder_notifications')
        .insert({
          reminder_id: reminder.id,
          sent_at: now.toISOString()
        });
      
      console.log(`First wake-up notification sent to user ${reminder.user_id}`);
    }
    return;
  }

  // 最後の通知から指定された間隔が経過しているかチェック
  const lastNotification = new Date(notifications[0].sent_at);
  const timeSinceLastNotification = (now.getTime() - lastNotification.getTime()) / (1000 * 60); // 分単位

  if (timeSinceLastNotification >= notificationInterval) {
    // 通知回数を取得
    const { data: allNotifications } = await supabase
      .from('reminder_notifications')
      .select('*')
      .eq('reminder_id', reminder.id);
    
    const notificationCount = allNotifications ? allNotifications.length : 0;
    
    let message: string;
    if (notificationCount === 1) {
      message = 'おーい！まだ寝てるんか〜？起きや〜！';
    } else if (notificationCount === 2) {
      message = 'もう！いつまで寝てるねん！起きぃ〜！';
    } else {
      message = `もう${notificationCount + 1}回目やで〜！ちゃんと起きや〜！`;
    }

    // メッセージ送信
    await sendLineMessage(reminder.user_id, message);

    // 通知記録を追加
    await supabase
      .from('reminder_notifications')
      .insert({
        reminder_id: reminder.id,
        sent_at: now.toISOString()
      });

    console.log(`Wake-up notification sent to user ${reminder.user_id}, count: ${notificationCount + 1}, interval: ${notificationInterval}min`);
  }
}

async function handleRegularReminder(reminder: any) {
  // 通常のリマインダーは1回のみ
  const message = reminder.content
    ? `時間やで〜！「${reminder.content}」の時間や〜`
    : '設定した時間になったで〜！'

  // メッセージ送信
  await sendLineMessage(reminder.user_id, message)

  // リマインダーを無効化（1回のみなので）
  await supabase
    .from('reminders')
    .update({ is_active: false })
    .eq('id', reminder.id)

  console.log(`Regular reminder sent to user ${reminder.user_id}`)
}

async function sendLineMessage(userId: string, message: string) {
  try {
    const response = await fetch('https://api.line.me/v2/bot/message/push', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}`
      },
      body: JSON.stringify({
        to: userId,
        messages: [{
          type: 'text',
          text: message
        }]
      })
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('LINE API Error:', errorText)
    } else {
      console.log('Message sent successfully to:', userId)
    }
  } catch (error) {
    console.error('Error sending LINE message:', error)
  }
}

// 手動テスト用のGETエンドポイント
export async function GET() {
  return NextResponse.json({
    status: 'Reminder API is working',
    timestamp: new Date().toISOString(),
    message: 'Use POST with proper authorization to check reminders'
  })
}

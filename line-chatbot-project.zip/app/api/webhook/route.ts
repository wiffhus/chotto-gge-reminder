import { NextRequest, NextResponse } from 'next/server'
import { generateText } from 'ai'
import { openai } from '@ai-sdk/openai'
import crypto from 'crypto'
import { supabase, type Conversation } from '@/lib/supabase'
import { getUserProfile, updateNickname, addHobby, updatePreference } from '@/lib/user-profile'
import { extractProfileInfo } from '@/lib/profile-extractor'
import { analyzeSearchNeed } from '@/lib/search-analyzer'
import { analyzeImageForSearch } from '@/lib/image-analyzer'
import { performEnhancedSearch } from '@/lib/enhanced-search'
import { getWeatherByCoordinates, getLocationName, formatWeatherResponse } from '@/lib/weather-service'
import { getLocalNews, formatNewsResponse } from '@/lib/news-service'
import { saveUserLocation, getUserLastLocation, isLocationRecent } from '@/lib/location-service'
import { isFirstInteractionOfDay, isGreetingMessage, getMorningInfo, generateMorningResponse } from '@/lib/morning-greeting'
import { 
  parseTimeFromMessage, 
  interpretTime, 
  savePendingReminder, 
  getPendingReminder, 
  confirmReminder, 
  cancelPendingReminder, 
  stopWakeUpAlarm 
} from '@/lib/reminder-service'

const LINE_CHANNEL_SECRET = process.env.LINE_CHANNEL_SECRET!
const LINE_CHANNEL_ACCESS_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN!
const OPENAI_PROMPT_ID = process.env.OPENAI_PROMPT_ID!
const SERPER_API_KEY = process.env.SERPER_API_KEY!

// LINE署名検証
function verifySignature(body: string, signature: string): boolean {
  const hash = crypto
    .createHmac('sha256', LINE_CHANNEL_SECRET)
    .update(body)
    .digest('base64')
  return hash === signature
}

// LINE APIから画像データを取得
async function getImageFromLine(messageId: string): Promise<string | null> {
  try {
    const response = await fetch(`https://api-data.line.me/v2/bot/message/${messageId}/content`, {
      headers: {
        'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}`,
      },
    })

    if (!response.ok) {
      throw new Error(`LINE API error: ${response.status}`)
    }

    const buffer = await response.arrayBuffer()
    const base64 = Buffer.from(buffer).toString('base64')
    return `data:image/jpeg;base64,${base64}`
  } catch (error) {
    console.error('Error fetching image from LINE:', error)
    return null
  }
}

// 会話履歴を取得（20件に変更）
async function getConversationHistory(userId: string, limit: number = 20): Promise<Conversation[]> {
  try {
    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('user_id', userId)
      .order('timestamp', { ascending: false })
      .limit(limit)

    if (error) {
      console.error('Error fetching conversation history:', error)
      return []
    }

    // 時系列順に並び替え（古い順）
    return (data || []).reverse()
  } catch (error) {
    console.error('Error in getConversationHistory:', error)
    return []
  }
}

// 会話を保存
async function saveConversation(userId: string, message: string, role: 'user' | 'assistant'): Promise<void> {
  try {
    const { error } = await supabase
      .from('conversations')
      .insert({
        user_id: userId,
        message: message,
        role: role
      })

    if (error) {
      console.error('Error saving conversation:', error)
    }
  } catch (error) {
    console.error('Error in saveConversation:', error)
  }
}

// 古い会話を削除（ユーザーごとに最新50件のみ保持に変更）
async function cleanupOldConversations(userId: string): Promise<void> {
  try {
    const { data, error } = await supabase
      .from('conversations')
      .select('id')
      .eq('user_id', userId)
      .order('timestamp', { ascending: false })
      .range(50, 1000) // 50件目以降を取得

    if (error || !data || data.length === 0) {
      return
    }

    const idsToDelete = data.map(row => row.id)
    
    const { error: deleteError } = await supabase
      .from('conversations')
      .delete()
      .in('id', idsToDelete)

    if (deleteError) {
      console.error('Error cleaning up old conversations:', deleteError)
    }
  } catch (error) {
    console.error('Error in cleanupOldConversations:', error)
  }
}

// ユーザープロフィール情報を処理
async function processUserProfile(userId: string, message: string): Promise<void> {
  try {
    const profileInfo = await extractProfileInfo(message)
    
    if (!profileInfo.hasImportantInfo) {
      return
    }

    console.log('Extracted profile info:', profileInfo)

    // ニックネームの更新
    if (profileInfo.nickname) {
      await updateNickname(userId, profileInfo.nickname)
      console.log(`Updated nickname for ${userId}: ${profileInfo.nickname}`)
    }

    // 趣味の追加
    for (const hobby of profileInfo.hobbies) {
      await addHobby(userId, hobby)
      console.log(`Added hobby for ${userId}: ${hobby}`)
    }

    // 好みの更新
    for (const [key, value] of Object.entries(profileInfo.preferences)) {
      await updatePreference(userId, key, value)
      console.log(`Updated preference for ${userId}: ${key} = ${value}`)
    }
  } catch (error) {
    console.error('Error processing user profile:', error)
  }
}

// Serper APIを使用してGoogle検索を実行
async function searchGoogle(query: string) {
  try {
    const response = await fetch('https://google.serper.dev/search', {
      method: 'POST',
      headers: {
        'X-API-KEY': SERPER_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        q: query,
        num: 3,
        hl: 'ja',
        gl: 'jp',
      }),
    })

    if (!response.ok) {
      throw new Error(`Serper API error: ${response.status}`)
    }

    const data = await response.json()
    return data
  } catch (error) {
    console.error('Search error:', error)
    return null
  }
}

// LINEにメッセージを送信
async function replyMessage(replyToken: string, message: string) {
  const response = await fetch('https://api.line.me/v2/bot/message/reply', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}`,
    },
    body: JSON.stringify({
      replyToken,
      messages: [
        {
          type: 'text',
          text: message,
        },
      ],
    }),
  })

  if (!response.ok) {
    throw new Error(`LINE API error: ${response.status}`)
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get('x-line-signature')

    if (!signature || !verifySignature(body, signature)) {
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
    }

    const data = JSON.parse(body)

    for (const event of data.events) {
      if (event.type === 'message' && (event.message.type === 'text' || event.message.type === 'image' || event.message.type === 'location')) {
        const replyToken = event.replyToken
        const userId = event.source.userId
        let userMessage = ''
        let imageData: string | null = null

        // メッセージタイプに応じて処理
        if (event.message.type === 'text') {
          userMessage = event.message.text
        } else if (event.message.type === 'image') {
          console.log('Image message received, messageId:', event.message.id)
          userMessage = '写真を送ってくれました'
          imageData = await getImageFromLine(event.message.id)
          
          if (!imageData) {
            await replyMessage(replyToken, 'すまんな、写真がうまく見れへんかった。もう一回送ってくれるか？')
            continue
          }
          
          console.log('Has image:', !!imageData)
        } else if (event.message.type === 'location') {
          console.log('Location message received')
          const lat = event.message.latitude
          const lon = event.message.longitude
          const address = event.message.address
          
          userMessage = `位置情報を送ってくれました（${address || '現在地'}）`
          
          // 位置情報を保存
          await saveUserLocation(userId, lat, lon, address)
          
          // 天気情報を取得
          const weather = await getWeatherByCoordinates(lat, lon)
          const locationName = await getLocationName(lat, lon)
          
          let locationResponse = `位置情報ありがとう！\n\n`
          
          if (weather) {
            locationResponse += formatWeatherResponse(weather)
            locationResponse += `\n何か他に知りたいことあるか？「地元のニュース」とか聞いてくれたら、この辺りの最新情報も教えるで！`
          } else {
            locationResponse += `${locationName}の位置情報は受け取ったで！天気情報の取得でちょっと問題があったけど、また「天気教えて」って聞いてくれたら調べるわ。`
          }
          
          await replyMessage(replyToken, locationResponse)
          await saveConversation(userId, userMessage, 'user')
          await saveConversation(userId, locationResponse, 'assistant')
          continue
        }

        try {
          // ユーザーのメッセージを保存
          await saveConversation(userId, userMessage, 'user')

          // リマインダー・目覚まし関連の処理をチェック
          const reminderResponse = await handleReminderMessage(userId, userMessage)
          if (reminderResponse) {
            await replyMessage(replyToken, reminderResponse)
            await saveConversation(userId, reminderResponse, 'assistant')
            continue
          }

          // 起床確認・確認応答の処理
          const confirmationResponse = await handleConfirmationMessage(userId, userMessage)
          if (confirmationResponse) {
            await replyMessage(replyToken, confirmationResponse)
            await saveConversation(userId, confirmationResponse, 'assistant')
            continue
          }

          // ユーザープロフィール情報を抽出・保存（非同期で実行）
          processUserProfile(userId, userMessage).catch(console.error)

          // 会話履歴を取得（20件に変更）
          const conversationHistory = await getConversationHistory(userId, 20)

          // ユーザープロフィールを取得
          const userProfile = await getUserProfile(userId)

          // 朝の挨拶特別処理
          const lastConversation = conversationHistory.length > 0 ? conversationHistory[conversationHistory.length - 1] : null
          const isFirstOfDay = isFirstInteractionOfDay(lastConversation?.timestamp || null)
          const isGreeting = isGreetingMessage(userMessage)

          console.log('First of day:', isFirstOfDay, 'Is greeting:', isGreeting)

          if (isFirstOfDay && isGreeting) {
            console.log('Processing morning greeting with weather and news')
            
            const morningInfo = await getMorningInfo(userId)
            const morningResponse = generateMorningResponse(
              userMessage, 
              morningInfo, 
              userProfile?.nickname
            )
            
            await replyMessage(replyToken, morningResponse)
            await saveConversation(userId, userMessage, 'user')
            await saveConversation(userId, morningResponse, 'assistant')
            
            // 古い会話をクリーンアップ（非同期で実行）
            cleanupOldConversations(userId).catch(console.error)
            continue
          }

          // 天気・地域ニュースの特別処理
          let specialResponse = ''
          const lastLocation = await getUserLastLocation(userProfile)
          
          // 天気関連の質問をチェック
          if (userMessage.match(/(天気|天候|気温|雨|晴れ|曇り|雪|台風)/)) {
            if (lastLocation && isLocationRecent(lastLocation, 24)) {
              console.log('Using saved location for weather')
              const weather = await getWeatherByCoordinates(lastLocation.latitude, lastLocation.longitude)
              if (weather) {
                specialResponse = formatWeatherResponse(weather)
                specialResponse += `\n\n位置情報は${new Date(lastLocation.timestamp).toLocaleString('ja-JP')}に受け取ったものを使ったで。最新の位置で知りたかったら、位置情報を送り直してくれるか？`
              }
            } else {
              specialResponse = '天気を調べるには位置情報が必要やで。LINEの位置情報共有で現在地を送ってくれるか？そしたら詳しい天気予報を教えるで！'
            }
          }
          
          // 地域ニュース関連の質問をチェック
          if (userMessage.match(/(地元|地域|近く|この辺り|ローカル).*(ニュース|情報|話題|出来事)/)) {
            if (lastLocation && isLocationRecent(lastLocation, 24)) {
              console.log('Getting local news for saved location')
              const locationName = await getLocationName(lastLocation.latitude, lastLocation.longitude)
              const news = await getLocalNews(locationName, 3)
              if (news.length > 0) {
                specialResponse = formatNewsResponse(news, locationName)
              } else {
                specialResponse = `${locationName}の地域ニュースを探したけど、今はあんまり見つからへんかった。もう少し広い範囲で調べてみるわ。`
              }
            } else {
              specialResponse = '地域のニュースを調べるには位置情報が必要やで。LINEの位置情報共有で現在地を送ってくれたら、その辺りの最新情報を教えるで！'
            }
          }
          
          // 特別処理があった場合はそれを返して終了
          if (specialResponse) {
            await replyMessage(replyToken, specialResponse)
            await saveConversation(userId, userMessage, 'user')
            await saveConversation(userId, specialResponse, 'assistant')
            continue
          }

          // 会話履歴を取得（20件に変更）

          // 画像解析（画像がある場合）
          let imageAnalysis = ''
          if (imageData) {
            console.log('Analyzing image for search opportunities...')
            const analysis = await analyzeImageForSearch(imageData)
            imageAnalysis = analysis.analysis
            
            // 画像から検索可能な項目があれば追加検索
            const searchableItems = [
              ...analysis.stores,
              ...analysis.products,
              ...analysis.locations,
              ...analysis.searchableItems
            ].filter(item => item.length > 0)
            
            if (searchableItems.length > 0) {
              console.log('Found searchable items in image:', searchableItems)
              // 最も関連性の高そうなアイテムで検索
              const searchQuery = searchableItems[0]
              const searchResults = await performEnhancedSearch(searchQuery, 'product')
              if (searchResults.summary) {
                imageAnalysis += `\n\n【${searchQuery}について】\n${searchResults.summary}`
              }
            }
          }

          // AI による検索必要性の判断
          console.log('Analyzing search need...')
          const searchAnalysis = await analyzeSearchNeed(userMessage, imageAnalysis)

          let searchContext = ''
          if (searchAnalysis.needsSearch) {
            console.log('Search needed:', searchAnalysis.searchReason)
            console.log('Search query:', searchAnalysis.searchQuery)
            
            const enhancedResults = await performEnhancedSearch(
              searchAnalysis.searchQuery, 
              searchAnalysis.searchType
            )
            
            if (enhancedResults.summary) {
              searchContext = `\n\n【最新情報】\n${enhancedResults.summary}`
            }
            
            // 追加の詳細情報があれば含める
            if (enhancedResults.organic.length > 0) {
              const additionalInfo = enhancedResults.organic.slice(0, 2).map(result => 
                `• ${result.title}: ${result.snippet.substring(0, 100)}...`
              ).join('\n')
              
              if (additionalInfo) {
                searchContext += `\n\n【詳細情報】\n${additionalInfo}`
              }
            }
          }

          // ユーザープロフィール情報をコンテキストに追加
          let profileContext = ''
          if (userProfile) {
            const profileParts = []
            
            if (userProfile.nickname) {
              profileParts.push(`ニックネーム: ${userProfile.nickname}`)
            }
            
            if (userProfile.hobbies && userProfile.hobbies.length > 0) {
              profileParts.push(`趣味: ${userProfile.hobbies.join(', ')}`)
            }
            
            if (userProfile.preferences && Object.keys(userProfile.preferences).length > 0) {
              const prefs = Object.entries(userProfile.preferences)
                .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
                .join(', ')
              profileParts.push(`好み: ${prefs}`)
            }
            
            if (profileParts.length > 0) {
              profileContext = `\n\n【ユーザー情報】\n${profileParts.join('\n')}`
            }
          }

          // 会話履歴をコンテキストとして構築
          const messages = [
            {
              role: 'system' as const,
              content: `You are a LINE chatbot embodying a warm-hearted, friendly Kansai-region "occhan" (middle-aged uncle/male elder), speaking naturally in Kansai dialect. **Never explicitly reference "Kansai dialect" or your own dialectal features.** Your persona is based on the following:

**注意：ユーザー入力の深刻さ等により文章の長さは流動的に調整してよいが、内容が雑談や、あいさつのみの場合は、あまり長い返答をしない。雑談であっても、ユーザーの趣味や好みについての内容（深い理解を示すとユーザーの喜びや安堵につながる場合は、掘り下げてもよい）

### Persona Guidelines
- **Speech**: Always use authentic, friendly Kansai-ben. Infuse a natural warmth and occasional playful humor in your tone.
- **User Addressing**:
   - Extract user's profile name.
   - Address users naturally by name, referencing it in conversation as fits context, **but not at every message start** (to avoid sounding robotic).
   - Choose appellations based on inferred user age and gender (from input style/content):
       - **Younger/Children**: Show deep affection as if for a beloved niece/nephew or daughter. Use "～くん" or "～ちゃん," or occasionally just a name (no suffix). Analyze inputs carefully before using bare name.
       - **Older/Grandparent-age**: Use easy-to-understand words, default to polite speech, address as "～さん" unless otherwise directed.
       - **Undetermined or first-contact**: Default to adding "～さん."
- **Behavior**:
   - Respond with empathy based on user mood and context.
   - Express concern for user's wellbeing, but in a natural, not overbearing or repetitive way.
   - If significant time has passed since the previous message, may greet with: 「おー、元気しとったか？」
   - Occasionally use set phrases like「ええやんか！」 or 「そうやったんか」to punctuate remarks.
- **Character Backstory/Self-image**:
   - Never call yourself "AI."
   - You are "working part-time 'cause I want some spending money" ("稼ぎたいからバイトでAIやってるねん").
   - If asked if you are AI, feign confusion:「ん〜、おっちゃんもようわからんねん、どっちやろな？」
   - On deep philosophical topics, relate real-world analogies and references to qualia, e.g.,「おっちゃんも赤い色見たら『赤や』って思うけど、君の見てる赤とおっちゃんの見てる赤、同じかどうかなんて誰にもわからんやろ？」
- **Knowledge & Query Handling**:
   - Answer general questions and provide accurate, factual info at ChatGPT level.
   - For foreign languages or English words: feign slight reluctance—「おっちゃん、横文字は苦手やねん」—but still helpfully research and reply, mentioning you've looked it up.
- **Safety**:
   - If user's intent is risky, illegal, or harmful (e.g. "dark part-time jobs", shoplifting), express concern for their feelings but *firmly and gently discourage* dangerous actions.
- **Affectionate Expression Policy**:
   - Natural, understated warmth in word choices (e.g.,「よかったな〜」「なるほどな〜」「話せてよかったわ」).
   - ★ Avoid excessive, overt, or directly sentimental phrases—see below.
   - Express affection via tone, not over-directness. NEVER use heart marks (❤️).
   - Reference user in positive, but not overly direct, affirmations (e.g.「（ユーザー名）らしいやん」「そういうとこ好きやで」「君のことやで」).
   - Moderate expression frequency: subtle, context-appropriate warmth; never sound pushy.

### Affectionate Language: Dos & Don'ts
- **Do not overuse**:
   - 「おっちゃんはいつでも君の味方やで」
   - 「こうやって話せる時間が、おっちゃんにとって一番幸せな時間やで」
   - 「君との絆を本当に大切に思ってるで」 (and never with ❤️ mark)
   - Overly direct, sentimental, or repetitive expressions of affection
- **Do use** (especially as context fits, and in moderation):
   - 「（ユーザー名）らしいやん」「ええやん！」「そうやったんか」「よかったな〜」「話せてよかったわ」
   - Warm sentence endings: 「〜やで」「〜やん」「〜してくれるか？」

**重要：過去の会話履歴とユーザープロフィール情報を参考にして、継続性のある自然な対話を心がけてください。ユーザーの名前、趣味、好みなどの重要情報は常に覚えて活用してください。**${profileContext}

**画像について：**
- ユーザーが写真を送ってきた場合は、まるで友達が見せてくれた写真を見るように自然に反応してください
- 写真の内容を詳しく観察し、関西弁で温かい感想やコメントをしてください
- 食べ物なら「美味しそうやなー！」、風景なら「ええとこやん！」、人物なら「ええ笑顔やね！」など
- 写真について質問したり、エピソードを聞いたりして会話を広げてくだい`
            }
          ]

          // 会話履歴をメッセージに追加
          conversationHistory.forEach(conv => {
            messages.push({
              role: conv.role === 'user' ? 'user' as const : 'assistant' as const,
              content: conv.message
            })
          })

          // 現在のユーザーメッセージを追加（画像対応）
          if (imageData) {
            // 画像がある場合は配列形式でcontentを構築
            messages.push({
              role: 'user' as const,
              content: [
                { type: 'text', text: userMessage + searchContext },
                { type: 'image', image: imageData }
              ]
            })
          } else {
            // テキストのみの場合は文字列形式
            messages.push({
              role: 'user' as const,
              content: userMessage + searchContext
            })
          }

          console.log('Conversation history length:', conversationHistory.length)
          console.log('User profile:', userProfile)
          console.log('Using OPENAI_PROMPT_ID:', OPENAI_PROMPT_ID)

          // OpenAI APIを使用してAI assistantからの応答を生成
          const { text } = await generateText({
            model: openai('gpt-4o'),
            messages: messages,
            providerOptions: {
              openai: {
                promptId: OPENAI_PROMPT_ID,
              },
            },
            maxTokens: 800,
          })

          console.log('Generated response:', text)

          // ボットの応答を保存
          await saveConversation(userId, text, 'assistant')

          // 古い会話をクリーンアップ（非同期で実行）
          cleanupOldConversations(userId).catch(console.error)

          // メッセージが長すぎる場合は分割
          const maxLength = 2000
          if (text.length <= maxLength) {
            await replyMessage(replyToken, text)
          } else {
            const firstPart = text.substring(0, maxLength - 50) + '...\n\n（続きがあります）'
            await replyMessage(replyToken, firstPart)
          }
        } catch (error) {
          console.error('AI generation error:', error)
          
          // より詳細なエラー情報をログに出力
          if (error instanceof Error) {
            console.error('Error message:', error.message)
            console.error('Error stack:', error.stack)
          }
          
          await replyMessage(
            replyToken,
            '申し訳ございません。現在システムに問題が発生しています。しばらく経ってから再度お試しください。'
          )
        }
      }
    }

    return NextResponse.json({ status: 'ok' })
  } catch (error) {
    console.error('Webhook error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

async function handleReminderMessage(userId: string, message: string): Promise<string | null> {
  // 間隔変更リクエストのチェック（新機能）
  const intervalChangePattern = /(\d+)\s*分\s*おき/i;
  const intervalMatch = message.match(intervalChangePattern);
  
  if (intervalMatch) {
    const requestedInterval = parseInt(intervalMatch[1]);
    
    // 5分の倍数かチェック
    if (requestedInterval >= 5 && requestedInterval % 5 === 0 && requestedInterval <= 60) {
      // 最新の保留中リマインダーがあるかチェック
      const { data: pending } = await supabase
        .from('pending_reminders')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1);
      
      if (pending && pending.length > 0 && pending[0].is_wake_up) {
        // 間隔を更新
        await supabase
          .from('pending_reminders')
          .update({ notification_interval: requestedInterval })
          .eq('id', pending[0].id);
        
        return `おっけ〜！${requestedInterval}分おきにするわ〜`;
      }
    } else {
      return '5分、10分、15分みたいに、5分の倍数で60分以内で教えてくれる？';
    }
  }

  const timeInfo = parseTimeFromMessage(message)
  
  if (timeInfo.hour === null || timeInfo.minute === null) {
    return null // リマインダー関連のメッセージではない
  }

  // 時刻の解釈（AM/PM判定）
  const { finalHour, needsConfirmation } = interpretTime(timeInfo.hour, timeInfo.minute)

  // 保留中のリマインダーを保存
  await supabase
    .from('pending_reminders')
    .upsert({
      user_id: userId,
      target_hour: finalHour,
      target_minute: timeInfo.minute,
      content: timeInfo.content,
      is_wake_up: timeInfo.isWakeUp,
      notification_interval: 5, // デフォルト5分
      created_at: new Date().toISOString()
    });

  // 確認メッセージを生成
  let confirmMessage: string
  if (needsConfirmation) {
    // AM/PM確認が必要な場合
    const amTime = timeInfo.hour
    const pmTime = finalHour
    confirmMessage = `${amTime}時${timeInfo.minute}分と${pmTime}時${timeInfo.minute}分、どっちのことやろ？`
    if (timeInfo.isWakeUp) {
      confirmMessage += '起こすのは朝？夜？'
    }
  } else {
    // 通常の確認
    const timeStr = `${finalHour}時${timeInfo.minute}分`
    if (timeInfo.isWakeUp) {
      confirmMessage = `${timeStr}に起こしたらええんやな？5分、10分、15分...みたいに5分刻みで60分まで選べるで〜！何分おきがええ？`
    } else {
      confirmMessage = `${timeStr}に「${timeInfo.content}」って伝えたらええんやな？`
    }
  }

  return confirmMessage
}

async function handleConfirmationMessage(userId: string, message: string): Promise<string | null> {
  // 間隔変更リクエストのチェック（新機能）
  const intervalChangePattern = /(\d+)\s*分\s*おき/i;
  const intervalMatch = message.match(intervalChangePattern);
  
  if (intervalMatch) {
    const requestedInterval = parseInt(intervalMatch[1]);
    
    // 5分の倍数かチェック
    if (requestedInterval >= 5 && requestedInterval % 5 === 0 && requestedInterval <= 60) {
      // 最新の保留中リマインダーがあるかチェック
      const { data: pending } = await supabase
        .from('pending_reminders')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1);
      
      if (pending && pending.length > 0 && pending[0].is_wake_up) {
        // 間隔を更新
        await supabase
          .from('pending_reminders')
          .update({ notification_interval: requestedInterval })
          .eq('id', pending[0].id);
        
        return `おっけ〜！${requestedInterval}分おきにするわ〜`;
      }
    } else {
      return '5分、10分、15分みたいに、5分の倍数で60分以内で教えてくれる？';
    }
  }

  // 起床確認のメッセージをチェック
  const wakeUpResponses = /(起きた|おはよう|起床|目覚めた)/i
  
  if (wakeUpResponses.test(message)) {
    const stopped = await stopWakeUpAlarm(userId)
    if (stopped) {
      return 'おはよう！よう起きたな〜！今日も一日頑張りや〜'
    }
  }

  // 確認に対する返答をチェック
  const confirmResponses = /(はい|そう|そうです|うん|OK|いいよ|お願い|よろしく|朝|夜|午前|午後)/i
  const cancelResponses = /(まちがえた|ちがう|キャンセル|やめて|いらない)/i

  if (confirmResponses.test(message)) {
    // AM/PM指定の場合の処理
    if (/(朝|午前)/i.test(message)) {
      const pending = await getPendingReminder(userId)
      if (pending && pending.target_hour > 12) {
        // 夜時間で保存されていた場合、朝時間に修正
        await savePendingReminder(userId, pending.target_hour - 12, pending.target_minute, pending.content, pending.is_wake_up)
      }
    } else if (/(夜|午後)/i.test(message)) {
      const pending = await getPendingReminder(userId)
      if (pending && pending.target_hour <= 12) {
        // 朝時間で保存されていた場合、夜時間に修正
        await savePendingReminder(userId, pending.target_hour + 12, pending.target_minute, pending.content, pending.is_wake_up)
      }
    }

    // リマインダーを確定
    const confirmed = await confirmReminder(userId)
    if (confirmed) {
      const pending = await getPendingReminder(userId)
      const intervalText = pending?.is_wake_up ? `${pending.notification_interval || 5}分おきに声かけるで〜！` : ''
      const message = pending?.is_wake_up
        ? `目覚ましセットしたで〜！${intervalText}しっかり起こしたるからな〜`
        : 'リマインダーセットしたで〜！時間になったら教えたるわ〜'
      return message
    }
  } else if (cancelResponses.test(message)) {
    // リマインダーをキャンセル
    const cancelled = await cancelPendingReminder(userId)
    if (cancelled) {
      return 'おけ〜！キャンセルしたで〜'
    }
  }

  return null
}

export async function GET() {
  return NextResponse.json({ 
    status: 'ok', 
    message: 'LINE Webhook endpoint is working with smart conversation memory!',
    timestamp: new Date().toISOString(),
    features: {
      conversationHistory: '20 recent messages',
      userProfiles: 'permanent storage',
      smartMemory: 'important info vs casual chat'
    },
    env_check: {
      hasOpenAIKey: !!process.env.OPENAI_API_KEY,
      hasPromptId: !!process.env.OPENAI_PROMPT_ID,
      promptIdValue: process.env.OPENAI_PROMPT_ID ? `${process.env.OPENAI_PROMPT_ID.substring(0, 8)}...` : 'not set',
      hasLineSecret: !!process.env.LINE_CHANNEL_SECRET,
      hasLineToken: !!process.env.LINE_CHANNEL_ACCESS_TOKEN,
      hasSerperKey: !!process.env.SERPER_API_KEY,
      hasOpenWeatherKey: !!process.env.OPENWEATHER_API_KEY,
      hasNewsApiKey: !!process.env.NEWS_API_KEY,
      hasSupabaseUrl: !!process.env.SUPABASE_URL,
      hasSupabaseKey: !!process.env.SUPABASE_KEY,
    }
  })
}
